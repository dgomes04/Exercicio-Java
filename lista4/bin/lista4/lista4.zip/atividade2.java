package lista4;

import java.util.Scanner;

public class atividade2 {
	public static int div(int dividendo,int divisor) {
		//Verifica se chegou no limite e retorna 0 para n�o haver altera��o no valor final
		if(dividendo<divisor) {
			return 0;
		}
		//Subtrai at� chegar no resultado contando cada vez que foi realizada somando +1
		return(div(dividendo-divisor,divisor)+1);
	}

	public static void main(String[] args) {
		Scanner ent = new Scanner(System.in);
		int num1, num2;
		//Entrada de valores
		System.out.println("Digite o dividendo: ");
		num1 = ent.nextInt();
		System.out.println("Digite o divisor: ");
		num2 = ent.nextInt();
		//Chamada de fun��o
		System.out.println(div(num1,num2));
		ent.close();
	}

}
