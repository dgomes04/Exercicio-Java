package lista4;

import java.util.Scanner;

public class atividade3 {
	public static int resto(int dividendo, int divisor) {
		//Verifica se chegou no limite e retorna o resto
		if(dividendo<divisor) {
			return(dividendo);
		}
		//Subtrai at� chegar no resto necess�rio(if)
		return(resto(dividendo-divisor,divisor));
	}

	public static void main(String[] args) {
		Scanner ent = new Scanner(System.in);
		int dividendo, divisor;
		//Entrada de valores
		System.out.println("Digite o dividendo:");
		dividendo = ent.nextInt();
		System.out.println("Digite o divisor:");
		divisor = ent.nextInt();
		//Chamada de fun��o
		System.out.println(resto(dividendo,divisor));
		ent.close();

	}

}
