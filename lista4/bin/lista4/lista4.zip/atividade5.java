package lista4;

import java.util.Scanner;

public class atividade5 {
	//Resolve o fatorial
	public static double fatorial(double n) {
		if(n==1) {
			return(1);
		}
		//subtrai 1 at� chegar no limite do if
		return(fatorial(n-1)*n);
	}
	//Faz a soma dos fatoriais
	public static double serie(int n) {
	
		if(n==1) {
			return(1);
		}
		
			
		return(serie(n-1) + (1/fatorial(n)));
	}
	
	public static void main(String[] args) {
		Scanner ent = new Scanner(System.in);
		int n;
		//Entrada de valores
		System.out.println("Digite o valor de N:");
		n = ent.nextInt();
		//chamada da fun��o
		System.out.println(serie(n));
		ent.close();

	}

}
