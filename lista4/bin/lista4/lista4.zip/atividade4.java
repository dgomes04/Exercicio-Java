package lista4;

import java.util.Scanner;

public class atividade4 {
	
	public static int mod(int x, int y) {
		//limite do c�digo
		if(x<y) {
			return(x);
		}
		//Verifica��o se os valores s�o iguais
		else if(x==y) {
			return(0);
		}
		//subtrai at� chegar no resto
		return(mod(x-y,y));
	}

	public static void main(String[] args) {
		Scanner ent = new Scanner(System.in);
		int x,y;
		//Entrada de valores
		System.out.println("Digite o valor de X:");
		x = ent.nextInt();
		
		System.out.println("Digite o valor de Y:");
		y = ent.nextInt();
		//Chamada de fun��o
		System.out.println(mod(x,y));
		ent.close();

	}

}
