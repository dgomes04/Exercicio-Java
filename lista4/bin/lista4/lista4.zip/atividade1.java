package lista4;

import java.util.Scanner;

public class atividade1 {
	
	public static int somaDigitos(int n) {
		int soma=0;
		//Limite
		if(n<1) {
			return n;
		}
		//Uso de % para retirar o ultimo d�gito
		soma += n%10;
		//Soma do ultimo d�gito com o n�mero sem esse mesmo d�gito
		return(soma+somaDigitos(n/10));
	}

	public static void main(String[] args) {
		Scanner ent = new Scanner(System.in);
		int numero;
		//Entrada de valores
		System.out.println("Digite o seu numero: ");
		numero = ent.nextInt();
		//Chamada de fun��o
		System.out.println(somaDigitos(numero));
		ent.close();
	}

}
